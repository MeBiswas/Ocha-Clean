define([], () => {
  const models = {
    name: 'pignoseCalendar',
    version: '1.4.31',
    preference: {
      supports: {
        themes: ['light', 'dark', 'blue']
      }
    }
  };
  return models;
});
